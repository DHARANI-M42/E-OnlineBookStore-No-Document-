<!DOCTYPE html>
<html>

 <body style="  background-image:linear-gradient(grey,white);">
 
 <div class="d-flex justify-content-center align-items-center"
	     style="min-height: 100vh;">
<center>
<marquee><h1><font color="RED">Let's Connect. We'd Love To Hear From You.</h1></marquee></font>
<h1><font color="darkPINK"> Be in touch :)</h1>
<h2><font color="green">Mobile : +91 9999900000 </font></h2>
<h2><font color="blue">Tel: 011-22509256 </font></h2>
<h2><font color="green">Email : onlinebookstore@gmail.com  </font><h2>
<h2><font color="blue">Address : Nava India, Coimbatore </font></h2>
<h1><font color="darkPINK">THANK YOU FOR VISITING THIS PAGE !</font></h1>
			
</body>
</html> 