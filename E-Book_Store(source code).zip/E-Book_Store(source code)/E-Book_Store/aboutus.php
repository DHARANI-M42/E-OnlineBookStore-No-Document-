</html> <!DOCTYPE html>
<html>
 <body style="  background-image:linear-gradient(lightyellow, grey);">
 <div class="d-flex justify-content-center align-items-center"
	     style="min-height: 100vh;">
<head>
	<title>Page Title</title>
	<style>
		h1 {
			color: green;
			font-size: 60px;
			text-align:CENTER;
		}
	</style>
</head>

<body>
	<center>
		<h1>
			<font color="PURPLE">WELCOME </font>
			<font color="RED">TO </font>
			<font color="PURPLE">FREE </font>
			<font color="RED">E-BOOK   </font>
			<font color="PURPLE">STORE </font>
			
			
		</h1>
		<h3><font color="black">We believe that bookstores are essential to a healthy culture.  </font></h3> 
<h2><font color="black">They’re where authors can connect with readers, where we discover new writers, 
where children get hooked on the thrill of reading that can last a lifetime.</font></h2> 
<h1><font color="GREEN">They’re also anchors for our downtowns and communities.  </font></h1>
<h2><font color="BLACK">As more and more people download their favorite books online, we wanted to create an easy,
convenient way for you to get your free books and support bookstores at the same time.  </font></h2>
		
		</H3>
		
	</center>
</body>

</html>
